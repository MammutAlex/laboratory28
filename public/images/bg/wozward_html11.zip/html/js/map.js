function initMap () {
	$(document).ready(function () {
		var mapOptions = {
					zoom: 6,
					scrollwheel: false,
					disableDefaultUI: true,
					center: new google.maps.LatLng(40.6700, -73.9400)
				};

		if ($('.js-map').length > 0) {
			$('.js-map:visible').each(function () {
				var map = new google.maps.Map($(this)[0], mapOptions),
					marker = new google.maps.Marker({
						position: { lat: 41.5, lng: -77 },
						map: map,
						icon: {
								url: 'img/map-marker.svg',
								size: new google.maps.Size(36, 48),
								anchor: new google.maps.Point(18, 48)
							}
					});
			});
		}

		if ($('.js-about-map').length > 0) {
			$('.js-about-map:visible').each(function () {
				var map = new google.maps.Map($(this)[0], mapOptions),
					marker = new google.maps.Marker({
						position: { lat: 41.5, lng: -77 },
						map: map,
						icon: {
								url: 'img/map-marker2.svg',
								size: new google.maps.Size(34, 47),
								anchor: new google.maps.Point(17, 47)
							}
					});
			});
		}

		$('.about--tab').on({
			click: function (e) {
					e.preventDefault();

					var _id = $(this).index() + 1;

					$('.about--tabs-box').removeClass('shown');
					$('.about--tabs-box:nth-child(' + _id + ')').addClass('shown');

					$('.about--tab').removeClass('active');
					$(this).addClass('active');

					var _map = new google.maps.Map($('.about--tabs-box:nth-child(' + _id + ')').find('.js-about-map')[0], mapOptions),
						_marker = new google.maps.Marker({
							position: { lat: 41.5, lng: -77 },
							map: _map,
							icon: {
									url: 'img/map-marker2.svg',
									size: new google.maps.Size(34, 47),
									anchor: new google.maps.Point(17, 47)
								}
							});
				}
		});

		$('.search-result--header').on({
			click: function () {
					var _result = $(this).closest('.search-result');

					$('.search-result').not(_result).removeClass('active');
					$('.search-result').not(_result).find('.search-result--body').slideUp(300);

					if (_result.hasClass('active')) {
						_result.removeClass('active');
						_result.find('.search-result--body').slideUp(300);
					} else {
						_result.addClass('active');
						_result.find('.search-result--body').slideDown(300, function () {
							if (_result.find('.search-result--map-in').length > 0)
								var mapS = new google.maps.Map(_result.find('.search-result--map-in')[0], mapOptions);
						});
					}
				}
		});

		$('.showModal').on({
			click: function (e) {
					e.preventDefault();

					var _id = $(this).attr('href');

					$('.modals--item').hide();
					$('.modals').fadeIn(300);
					$('.modals--item' + _id).fadeIn(300, function () {
						if ($(this).find('.js-modal-map').length > 0) {
							var map = new google.maps.Map($(this).find('.js-modal-map')[0], mapOptions),
								marker = new google.maps.Marker({
										position: { lat: 41.5, lng: -77 },
										map: map,
										icon: {
												url: 'img/map-marker.svg',
												size: new google.maps.Size(36, 48),
												anchor: new google.maps.Point(18, 48)
											}
									});
						}
					});
				}
		});

		$('.modals--close, .modals--overlay').on({
			click: function (e) {
					e.preventDefault();

					$('.modals').fadeOut(300);
					$('.modals--item').fadeOut(300);
				}
		});
	});
}