function nextChar (c) { return String.fromCharCode(c.charCodeAt(0) + 1); }

$(document).on('ready', function () {

	$('a[href=#]').on({
		click: function (e) {
				e.preventDefault();

				console.log('Click on a[href=#]');
			}
	});

	$('a[disabled], a.disabled').on({
		click: function (e) {
				e.preventDefault();
				e.stopPropagation();

				return false;
			}
	});

	$('.auth--tab').on({
		click: function (e) {
				e.preventDefault();

				var _id = $(this).index() + 1;

				$('.auth--tabs-box').removeClass('shown');
				$('.auth--tabs-box:nth-child(' + _id + ')').addClass('shown');

				$('.auth--tab').removeClass('active');
				$(this).addClass('active');
			}
	});

	$('.order-info--tab').on({
		click: function (e) {
				e.preventDefault();

				var _id = $(this).index() + 1;

				$('.order-info--tabs-box').removeClass('shown');
				$('.order-info--tabs-box:nth-child(' + _id + ')').addClass('shown');

				$('.order-info--tab').removeClass('active');
				$(this).addClass('active');
			}
	});

	$('a.c-settings--spoiler-t').on({
		click: function (e) {
				e.preventDefault();

				var _spoiler = $(this).closest('.c-settings--spoiler'),
					_box = _spoiler.find('.c-settings--spoiler-in');

				_spoiler.toggleClass('hidden');
				_box.slideToggle();
			}
	});

	$('.magic-radio').on({
		click: function () {
				var _t = $(this),
					_btns = _t.closest('.magic-radio--group').find('.magic-radio').not(_t);

				_btns.removeClass('active');
				_t.addClass('active');

				$('.magic-radio').not(_t).find('.magic-radio--in').hide();
				_t.find('.magic-radio--in').fadeIn(300);
			}
	});

	$(document).on('click', function (e) {
		if ($('.magic-radio--in:visible').length && !$(e.target).closest('.magic-radio').length) {
			$('.magic-radio--in').hide();
		}
	});

	$('.file-input--in').on('change', function () {
		console.log($(this).val());

		var _val = $(this).val();

		_val = _val.substr(_val.lastIndexOf("\\") + 1, _val.length);

		$(this).closest('.file-input').find('.file-input--link span').html(_val);
	});

	$('.input-phone').intlTelInput({
		utilsScript: 'js/utils.js',
		nationalMode: false
	});

	$('.input-date').datepicker({
		autoHide: true,
		autoPick: true,
		format: 'dd-mm-yyyy'
	});

	$('.t-orders--stats-toggle a').on({
		click: function (e) {
				e.preventDefault();

				var _t = $(this),
					_in = _t.closest('.t-orders--stats').find('.t-orders--stats-in');

				_in.slideToggle(300);
				$('.t-orders--stats-toggle a').toggleClass('active');
			}
	});

	$('.c-new--toggle a').on({
		click: function (e) {
				e.preventDefault();

				var _t = $(this),
					_in = _t.closest('.t-signup--box').find('.c-new--tabin');

				_in.slideToggle(300);
				$('.c-new--toggle a').toggleClass('active');
			}
	});

	if ($('.t-orders--stats-chart-i').length > 0) {
		$('.t-orders--stats-chart-i').easyPieChart({
			lineWidth: 14,
			lineCap: 'butt',
			scaleColor: false,
			trackColor: '#4a4a4a',
			barColor: '#f9e242',
			size: 94,
			animate: false
		});
	}

	$('.form-field--delete').on({
		click: function (e) {
				e.preventDefault();

				var _t = $(this),
					_input = _t.closest('.form-field').find('.form-field--input');

				_input.attr('value', '');
				_input.focus();
			}
	});

	$('.rating.to-change').on({
		mousemove: function (e) {
				var _e = $(e.toElement);

				if (_e.is('i')) {
					var _t = $(this),
						_i = _e.parent().index() + 1;

					_t.removeClass('s1 s2 s3 s4 s5');
					_t.addClass('s' + _i);

					_t.data('selected', _i);
				}
			},

		mouseleave: function (e) {
				var _t = $(this),
					_r = _t.data('real');

				_t.removeClass('s1 s2 s3 s4 s5').addClass('s' + _r);
				_t.data('selected', '');
			},

		click: function () {
				var _t = $(this),
					_s = _t.data('selected');

				_t.data('real', _s);
				_t.removeClass('s1 s2 s3 s4 s5').addClass('s' + _s);
			}
	});

	$('.t-main--list-link').on({
		click: function (e) {
				e.preventDefault();

				$(this).parent().find('.t-main--list-ul.hidden').slideDown(300);
				$(this).hide();
			}
	});

	$('.t-main--text-btn .btn').on({
		click: function (e) {
				e.preventDefault();

				var _t = $(this),
					_in = _t.closest('.t-main--text').find('.t-main--text-in');

				_in.css('height', 'auto');
				_in.addClass('active');
				_t.hide();
			}
	});

	$('.t-main--reviews-in').slick({
		prevArrow: '<span class="slick-arrow slick-prev"><i class="fa fa-angle-left"></i></span>',
		nextArrow: '<span class="slick-arrow slick-next"><i class="fa fa-angle-right"></i</span>'
	});

	$('.c-new--radio').on({
		click: function (e) {
				e.preventDefault();

				$(this).closest('.c-new--radios').find('.active').removeClass('active');
				$(this).addClass('active');
			}
	});

	$('.variant-row').on({
		click: function (e) {
				e.preventDefault();

				$('.variant-row').removeClass('active');
				$(this).addClass('active');
			}
	});

	$('.order-stats--tab').on({
		click: function (e) {
				e.preventDefault();

				$('.order-stats--tab').removeClass('active');
				$(this).addClass('active');
			}
	});

	$('.c-signup--form-toggle').on({
		click: function (e) {
				e.preventDefault();

				$('.c-signup--form').toggleClass('shown');
				$('.c-signup--form.shown input[type=text]').first().focus();
			}
	});

	$('input[type=radio]').on({
		change: function (e) {
				var _formToggler = $('.radiobox.c-signup--form-ctoggler input[type=radio]');

				if (_formToggler.length > 0) {
					var _value = _formToggler.prop('checked');

					$('.c-signup--form-ctoggle').css('display', (_value) ? 'block' : 'none');
				}
			}
	});

	$('.helper').tooltip();

	$(document).on('click', '.js-increment-link', function (e) {
		e.preventDefault();

		var _lastPoint = $('.js-increment-box').last(),
			_lastPointPhone = _lastPoint.find('.input-phone');

		_lastPointPhone.intlTelInput('destroy');

		var _newPoint = _lastPoint.clone(true);

		_lastPointPhone.intlTelInput();

		_newPoint.insertAfter(_lastPoint);

		var _newPointCounter = _newPoint.find('.js-increment-counter'),
			_newPointPhone = _newPoint.find('.input-phone'),
			_newPointInput = _newPoint.find('input[type=text]').first();

		_newPointCounter.html(nextChar(_newPointCounter.html()));
		_newPointPhone.intlTelInput();
		_newPointInput.focus();

		if (!($(this).hasClass('js-dremove')))
			$(this).remove();

		$(window).trigger('scroll');
	});

	$(window).on('load scroll resize', function () {
		var _window = $(this),
			_recallBtn = $('.recall-btn');

		if (_recallBtn.length > 0) {
			_recallBtn.css('display', (_window.scrollTop() > 729) ? 'block' : 'none');
		}
	});

	$('.header--profile').on({
		click: function (e) {
				e.preventDefault();

				$(this).closest('.header').find('.header--profile-box').slideToggle(200);
			}
	});

	$('.js-fixedscroll').each(function () {
		var _fBox = $(this),
			_fBoxParent = _fBox.parent(),
			_fParent = _fBox.closest('.js-fixedscroll-parent');

		if (_fParent.length > 0) {
			$(window).on('load resize scroll', function () {
				var _window = $(this);

				if (_window.scrollTop() > _fParent.offset().top) {
					_fBox.css({
						position: 'fixed',
						width: _fBoxParent.outerWidth(),
						left: _fBoxParent.offset().left
					});

					if (_window.scrollTop() + _fBox.outerHeight() + 70 > _fParent.offset().top + _fParent.outerHeight() - 70) {
						_fBox.css('top', (_fParent.offset().top + _fParent.outerHeight()) - (_window.scrollTop() + _fBox.outerHeight()) - 70);
					} else {
						_fBox.css('top', 70);
					}
				} else {
					_fBox.css({
						position: 'relative',
						width: 'auto',
						left: 'auto',
						top: 'auto'
					});
				}
			});
		}
	});

	$('.parallax').scrolly();

	$('.chosen-select').chosen();

	if ($('#chart').length > 0) {
		Highcharts.chart('chart', {
			chart: {
				backgroundColor: 'transparent',
				type: 'column',
				spacingRight: 5,
				spacingLeft: 0,
				plotBorderWidth: 1,
				plotBorderColor: '#f1f1f1',
				width: null,
				height: 300
			},

			title: { text: '' },
			credits: { enabled: false },
			xAxis: {
				tickWidth: 0,
				lineColor: '',
				gridLineWidth: 0,
				categories: ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вc'],
			},

			colors: [ '#f9e34c', '#f6f6f6' ],
			yAxis: {
				gridLineWidth: 0,
				title: {
					text: 'Километраж в тис',
					style: {
						"font": "900 14px/20px 'Circe', arial, sans-serif",
						"color": "#4a4a4a"
					}
				},
			},

			plotOptions: {
				column: {
					groupPadding: 0.06,
					pointPadding: 0,
					borderWidth: 0,

					states: { hover: { brightness: 0 } }
				}
			},

			legend: { enabled: true },
			navigation: { buttonOptions: { enabled: false } },
			series: [
				{ name: 'С грузом', data: [0.6, 0.35, 0.75, 1.2, 0.6, 1.2, 1.4] },
				{ name: 'Без груза', data: [1.2, 1.3, 1, 0.35, 0.9, 1.3, 0.35] }
			]
		});
	}

	if ($('#lineChart').length > 0) {
		Highcharts.chart('lineChart', {
			chart: {
				backgroundColor: 'transparent',
				type: 'column',
				spacingRight: 5,
				spacingLeft: 0,
				plotBorderWidth: 1,
				plotBorderColor: '#f1f1f1',
				width: null,
				height: 300
			},

			title: { text: '' },
			credits: { enabled: false },
			xAxis: {
				tickWidth: 0,
				lineColor: '',
				gridLineWidth: 1,
				gridLineColor: '#f5f5f5',
				categories: [ 'МАЙ', 'ИЮН', 'ИЮЛЬ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', 'ЯНВ', 'ФЕВ', 'МАП', 'АПР' ],
			},

			colors: [ '#f9e242', '#e5bf4d' ],
			tooltip: { enabled: false },
			yAxis: {
				gridLineWidth: 1,
				gridLineColor: '#f5f5f5',
				title: {
					text: 'Тент 20т, цена грн / км',
					style: {
						"font": "900 14px/20px 'Circe', arial, sans-serif",
						"color": "#4a4a4a"
					}
				},
			},

			plotOptions: {
				area: {
					fillColor: {
						linearGradient: { x1: 0, y1: 0, x2: 0, y2: 0.9},
						stops: [
							[0, '#f9e242'],
							[1, 'rgba(249, 226, 66, 0)']
						]
					},
					lineWidth: 1,
					marker: {
						enabled: true,
						fillColor: "#ffffff",
						lineColor: "#f9e242",
						lineWidth: 2
					},
					shadow: false,
					states: {
						hover: {
							lineWidth: 1
						}
					},
					threshold: null
				},
				spline: {
					connectNulls: true,
					dashStyle: "ShortDash",
					marker: { enabled: false },
					states: {
						hover: {
							lineWidthPlus: 0,
							marker: { enabled: false }
						}
					}
				}
			},

			legend: { enabled: true },
			navigation: { buttonOptions: { enabled: false } },
			series: [
				{ name: 'График изменения цены', type: 'area', data: [16, 17, 16.5, 18, 17, 17.5, 16.5, 18.5, 17.5, 17.75, 17.5] },
				{ name: 'Тренд', type: 'spline', data: [16.2, null, 16, null, null, null, null, 18.6, null, null, 18] }
			]
		});
	}

	$('.form-field--input').on({
		focus: function () {
				var _t = $(this),
					_efield = _t.closest('.form-field.error'),
					_erow = _t.closest('.c-main--form-row.error');

				if (_efield.length > 0) {
					_t.val('');
					_efield.removeClass('error');

					if (_erow.length > 0) {
						_erow.removeClass('error');
						_erow.find('.form-field').removeClass('error');
						_erow.find('.form-field--input').val('');
					}
				}
			}
	});

	$('.header--profile-notify').on({
		click: function (e) {
				e.preventDefault();
				e.stopPropagation();

				var _header = $(this).closest('.header');

				_header.find('.header--profile-box').slideUp(200);
				_header.find('.header--profile-nbox').slideToggle(200);

				return false;
			}
	});

	$('.header--profile-nbox > a.blue-link').on({
		click: function (e) {
				e.preventDefault();

				$(this).parent().find('.header--profile-nitem').removeClass('hidden');
				$(this).hide();
			}
	});

	$(document).on('click', function (e) {
		if ($('.header--profile-nbox:visible').length && !$(e.target).closest('.header--profile-nbox').length && !$(e.target).is('.header--profile-notify')) {
			$('.header--profile-nbox').slideUp(200);
		}
	});

	// Select

		$('.js-select').each(function () {
			var self = $(this);

			self.find('.js-select_input').val(self.find('.js-select_list li:first').attr('data-value'));
		});

		$('.js-select_in').on('click', function () {
			var self = $(this),
				select = self.closest('.js-select'),
				option_list = select.find('.js-select_list');

			if (option_list.is(':visible')) {
				option_list.slideUp(200);
				select.removeClass('is-opened');
				self.find('.js-select_arrow').removeClass('is-active');
			} else {
				if ($('.js-select .js-select_list:visible').length) {
					$('.js-select .js-select_list:visible').hide();
					$('.js-select .js-select_arrow').removeClass('is-active');
				}

				option_list.slideDown(200);
				select.addClass('is-opened');
				self.find('.arrow').addClass('is-active');
			}
		});

		$('.js-select_list li').on('click', function () {
			var self = $(this),
				title = self.closest('.js-select').find('.js-select_in .js-select_title'),
				option = self.html();

			title.html(option);
			self.closest('.js-select').find('input[type=hidden]').val(self.attr('data-value'));
			self.closest('.js-select_list').find('li').removeClass('is-active');
			self.addClass('is-active');
			self.closest('.js-select_list').slideUp(200);
			self.closest('.js-select').removeClass('is-opened');
			self.closest('.js-select').find('.js-select_arrow').removeClass('is-active');
		});

		$(document).on('click', function (e) {
			if ($('.js-select .js-select_list:visible').length && !$(e.target).closest('.js-select').length) {
				$('.js-select').removeClass('is-opened');
				$('.js-select .js-select_list').slideUp(200);
				$('.js-select .js-select_arrow').removeClass('is-active');
			}
		});

		$(document).keyup(function(e){
			if (e.keyCode == 27) {
				$('.js-select').removeClass('is-opened');
				$('.js-select .js-select_list').slideUp(200);
			}
		});

});