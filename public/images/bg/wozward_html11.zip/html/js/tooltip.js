(function($) {

	$.fn.tooltip = function(options) {
		return this.each(function() {
			var _box = $(this),
				_tip = '.tooltip';

			_box.hover(
				function () {
					var _out = $('<div class="tooltip"><div class="tooltip--in">' + $(this).attr('data-tip') + '</div></div>').appendTo('body');

					_out.css({
						'top': _box.offset().top - $(window).scrollTop() - _out.outerHeight(),
						'left': _box.offset().left + (_box.outerWidth() / 2)
					});

					$(window).on('resize scroll', function () {
						_out.css({
							'top': _box.offset().top - $(window).scrollTop() - _out.outerHeight(),
							'left': _box.offset().left + (_box.outerWidth() / 2)
						});
					});

					$(_tip).fadeIn(300);
				},

				function () {
					$(_tip).remove();
				}
			);

		});
	};
	
})(jQuery);